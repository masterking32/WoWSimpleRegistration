chardumps = chardumps or {};
