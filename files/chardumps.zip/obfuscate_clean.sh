rm -f *.bak
rm -f *_ob.lua
rm addon.lua
