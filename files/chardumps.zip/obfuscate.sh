concat.sh

luaob -a addon.lua -opt-const_string

read
