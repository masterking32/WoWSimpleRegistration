local chardumps = chardumps;

local config = {};

function config:GetWarningColor()
  return 0.93, 0.6196, 0.18;
end

chardumps.config = config;
